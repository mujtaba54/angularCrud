import { Injectable } from '@angular/core';
import { InMemoryDbService } from 'angular-in-memory-web-api';
import { Data } from './data';

@Injectable({
  providedIn: 'root',
})

export class InMemoryDataService implements InMemoryDbService {
  createDb() {
    const Data = [
        {
            id: 1,
            org_Name: 'Cisco',
            emp_Name: 'Naruto',
            age: 26,
            salary: 5600,
            dept_Name: 'Management'
        },
        {
            id: 2,
            org_Name: 'Nvidia',
            emp_Name: 'Kirito',
            age: 23,
            salary: 8000,
            dept_Name: 'Developers'
        },
        {
            id: 3,
            org_Name: 'Intel',
            emp_Name: 'Max',
            age: 20,
            salary: 4000,
            dept_Name: 'QA'
        }
    ];
    return { Data };
  }

  generateRandomId(data: Data[]): number {
    return data.length > 0 ? Math.max(...data.map(item => item.id)) + 1 : 11;
  }
}

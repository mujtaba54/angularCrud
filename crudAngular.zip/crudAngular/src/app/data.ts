export class Data {
    id: number;
    org_Name: string;
    emp_Name: string;
    age: number;
    salary: number;
    dept_Name: string;
}
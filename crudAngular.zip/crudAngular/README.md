# AngularCRUD

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

## Features
1. User Page
    Contains Users Info where we can perform CRUD Operations like
      1. Add Record 
      2. Edit Record
      3. Delete Record
      3. Sorting 
      4. Formatting: 'Amount/Text/Number' in the column 
      5. Search


